template<typename T>
class vector
{
	T* buff;
public:
	void resize(std::size_t sz)
	{
		buff = allocate(sz);

		deallocate(buff, sz);
	}
	virtual T* allocate(std::size_t sz) { return new T[sz]; }
	virtual void deallocate(T* p, std::size_t sz) { delete[] p; }
};

int main()
{

}